const arr = [1, 2, 3];

arr.forEach(console.log);