var score = 80;
score = 90;

console.log(score)