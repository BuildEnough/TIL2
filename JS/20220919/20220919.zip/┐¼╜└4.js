console.log(score);

var score;