console.log(score);

score = 80;

var score;

console.log(score);