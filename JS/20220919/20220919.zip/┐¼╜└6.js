console.log(score);

var score = 80;

console.log(score)