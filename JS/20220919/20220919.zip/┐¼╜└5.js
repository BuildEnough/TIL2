var score;
score = 80;

var score = 80;